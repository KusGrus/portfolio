import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/storage';
import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Product } from '../interfaces';

@Injectable({ providedIn: 'root' })
export class StoreService {
  constructor(
    private http: HttpClient,
    private firestore: AngularFireStorage
  ) {}

  getAll() {
    return this.http
      .get(`${environment.firebaseConfig.databaseURL}/store.json`)
      .pipe(
        map((respose) => {
          return Object.keys(respose).map((key) => ({
            ...respose[key],
            id: key,
          }));
        })
      );
  }

  getById(id: string): Observable<Product> {
    return this.http
      .get(`${environment.firebaseConfig.databaseURL}/store/${id}.json`)
      .pipe(
        map((item: Product) => {
          return {
            ...item,
            id,
            review: item.review ? item.review : [],
          };
        })
      );
  }

  create(item: Product): Observable<Product> {
    return this.http
      .post<Product>(
        `${environment.firebaseConfig.databaseURL}/store.json`,
        item
      )
      .pipe(
        tap(() => {
          this.pastedImage(item.name, item.extraImg);
        })
      );
  }

  pastedImage(bike: string, images: Array<string | ArrayBuffer>): void {
    images.forEach((element, index) => {
      let filePath = `${this._toCamelCase(bike)}/image_${index}`;
      const fileRef = this.firestore.ref(filePath);
      this.firestore.upload(filePath, element);
      fileRef.getDownloadURL().subscribe((url)=>{
        
      })
    });
  }

  _toCamelCase(str: string): string {
    return str.split(' ').reduce((acc, cur) => {
      return acc + cur[0].toUpperCase() + cur.slice(1);
    }, '');
  }
}
